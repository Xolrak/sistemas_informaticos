Write-Host "Bienvenido al menú de ajustes de permisos"
