#!/bin/bash
clear
echo "hola mundo"