#!/bin/bash
# Limpia la pantalla
clear
# Muestra la información de los usuarios conectados
who
# Explicación de los comandos:
# clear: Este comando borra la pantalla.
# who: Este comando muestra una lista de los usuarios que están conectados al sistema.